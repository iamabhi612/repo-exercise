import React from 'react';

const projects = [
  {
    title: 'Project 1',
    description: 'This is the description of project 1.',
    link: 'https://example.com/project1',
  },
  {
    title: 'Project 2',
    description: 'This is the description of project 2.',
    link: 'https://example.com/project2',
  },
  // Add more projects as needed
];

const App = () => {
  return (
    <div className="container">
      <header className="header">
        <h1 className="title">My Portfolio</h1>
        <p className="subtitle">Welcome to my portfolio website!</p>
      </header>
      <div className="content">
        <h2>Projects</h2>
        {projects.map((project, index) => (
          <div className="project" key={index}>
            <h3 className="project-title">{project.title}</h3>
            <p className="project-description">{project.description}</p>
            <a className="project-link" href={project.link}>
              View Project
            </a>
          </div>
        ))}
      </div>
    </div>
  );
};

export default App;
